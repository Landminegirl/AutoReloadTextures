import bpy
from bpy.types import Panel, Operator, AddonPreferences, Menu
from bpy.props import IntProperty, BoolProperty
from threading import Thread
import time

class ReloadTexturesOperator(Operator):
    """Reload all textures"""
    bl_idname = "material.reload_textures"
    bl_label = "Reload Textures"

    def execute(self, context):
        for image in bpy.data.images:
            if image.source == 'FILE':  # Only reload file-based textures
                image.reload()
        self.report({'INFO'}, "Textures reloaded")
        return {'FINISHED'}

class ReloadTexturePreferences(AddonPreferences):
    bl_idname = __name__

    reload_interval: IntProperty(
        name="Reload Interval (seconds)",
        default=10,
        min=1,
        description="Interval at which textures will be automatically reloaded",
    )
    auto_reload: BoolProperty(
        name="Auto Reload",
        default=False,
        description="Automatically reload textures at the specified interval",
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "reload_interval")
        layout.prop(self, "auto_reload")

class ReloadTexturesPanel(Panel):
    """Creates a Panel in the texture context of the properties editor"""
    bl_label = "Auto Reload Textures"
    bl_idname = "MATERIAL_PT_reload_textures"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Textures"

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__name__].preferences

        layout.operator("material.reload_textures", text="Reload Now")
        layout.prop(prefs, "reload_interval")
        layout.prop(prefs, "auto_reload")

class ReloadTexturesMenu(Menu):
    """Menu for Reload Textures"""
    bl_label = "Reload Textures Menu"
    bl_idname = "VIEW3D_MT_reload_textures_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("material.reload_textures", text="Reload Now")

def draw_reload_textures_menu(self, context):
    """Function to append the menu to the View menu"""
    self.layout.menu(ReloadTexturesMenu.bl_idname, text="Reload Textures")

class ReloadTexturesManager:
    _thread = None
    _running = True

    @staticmethod
    def start():
        if ReloadTexturesManager._thread is None:
            ReloadTexturesManager._running = True
            ReloadTexturesManager._thread = Thread(target=ReloadTexturesManager.run)
            ReloadTexturesManager._thread.daemon = True
            ReloadTexturesManager._thread.start()

    @staticmethod
    def stop():
        ReloadTexturesManager._running = False
        if ReloadTexturesManager._thread:
            ReloadTexturesManager._thread.join()
            ReloadTexturesManager._thread = None

    @staticmethod
    def run():
        while ReloadTexturesManager._running:
            prefs = bpy.context.preferences.addons[__name__].preferences
            if prefs.auto_reload:
                for image in bpy.data.images:
                    if image.source == 'FILE':  # Only reload file-based textures
                        image.reload()
            time.sleep(prefs.reload_interval)

def register():
    bpy.utils.register_class(ReloadTexturesOperator)
    bpy.utils.register_class(ReloadTexturePreferences)
    bpy.utils.register_class(ReloadTexturesPanel)
    bpy.utils.register_class(ReloadTexturesMenu)
    bpy.types.VIEW3D_MT_editor_menus.append(draw_reload_textures_menu)
    ReloadTexturesManager.start()

def unregister():
    ReloadTexturesManager.stop()
    bpy.utils.unregister_class(ReloadTexturesOperator)
    bpy.utils.unregister_class(ReloadTexturePreferences)
    bpy.utils.unregister_class(ReloadTexturesPanel)
    bpy.utils.unregister_class(ReloadTexturesMenu)
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_reload_textures_menu)

if __name__ == "__main__":
    register()